//
//  ViewController.swift
//  Food Selection
//
//  Created by Rafael Tomaz Prado on 22/03/17.
//  Copyright © 2017 Rafael Tomaz Prado. All rights reserved.
//

import UIKit

class ViewController: UIViewController, BehaviourProtocol, UITableViewDataSource{
    
    fileprivate var behaviour = Behaviour()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var removeAllButton: UIButton!
    @IBOutlet weak var hamburgerButton: UIButton!
    @IBOutlet weak var iceCreamButton: UIButton!
    @IBOutlet weak var pizzaButton: UIButton!
    @IBOutlet weak var noodlesButton: UIButton!
    @IBOutlet weak var chickenButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.behaviour.delegate = self
        removeAllButton.isHidden = true
        hamburgerButton.layer.cornerRadius = 2.0
        iceCreamButton.layer.cornerRadius = 2.0
        pizzaButton.layer.cornerRadius = 2.0
        noodlesButton.layer.cornerRadius = 2.0
        chickenButton.layer.cornerRadius = 2.0
    }
    
    @IBAction func buttonIsPressed(_ sender: UIButton){
        if let option = sender.titleLabel?.text{
            self.behaviour.chooseOption(option)
        }
        removeAllButton.isHidden = false
        totalLabel.text = ("\(behaviour.choiceArray.count) items - Total: $\(behaviour.totalPrice)")
        tableView.reloadData()
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return behaviour.choiceArray.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! CellController
        cell.icon.text = behaviour.choiceArray[indexPath.row].icon
        cell.name.text = behaviour.choiceArray[indexPath.row].name
        cell.price.text = "$"+String(behaviour.choiceArray[indexPath.row].price)
        return cell
    }

    @IBAction func removeAllButton(_ sender: UIButton) {
        behaviour.choiceArray.removeAll()
        behaviour.totalPrice = 0.0
        totalLabel.text = ("\(behaviour.choiceArray.count) items - Total: $\(behaviour.totalPrice)")
        tableView.reloadData()
        removeAllButton.isHidden = true
    }
    
    
}

