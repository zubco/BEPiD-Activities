//
//  LocationCell.swift
//  AirMonitor
//
//  Created by Rafael Tomaz Prado on 28/08/17.
//  Copyright © 2017 BEPiD. All rights reserved.
//

import UIKit

class LocationCell: UITableViewCell {
    @IBOutlet weak var cityName: UILabel!

}
