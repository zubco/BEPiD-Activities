# SceneKit State of the Union Demo

Translated by OOPer in cooperation with shlab.jp, on 2015/12/13.

Based on
<https://developer.apple.com/library/content/samplecode/SceneKitReel/Introduction/Intro.html#//apple_ref/doc/uid/TP40014550>
2017-03-09.

As this is a line-by-line translation from the original sample code, "redistribute the Apple Software in its entirety and without modifications" would apply. See LICENSE.txt .
Some faults caused by my translation may exist. Not all features tested.
You should not contact to Apple or SHLab(jp) about any faults caused by my translation.


## Build Requirements

iOS SDK 10 or later/macOS SDK 10.12 or later
