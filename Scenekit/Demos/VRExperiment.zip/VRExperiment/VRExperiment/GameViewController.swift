//
//  GameViewController.swift
//  VRExperiment
//
//  Created by Gustavo Lima on 2/13/17.
//  Copyright © 2017 Gustavo Lima. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit
import CoreMotion

func degreesToRadians(_ degrees: Float) -> Float {
    return (degrees * .pi) / 180.0
}

func radiansToDegrees(_ radians: Float) -> Float {
    return (180.0 / .pi) * radians
}

class GameViewController: UIViewController {

    @IBOutlet weak var leftView: SCNView!
    @IBOutlet weak var rightView: SCNView!
    
    
    var scnScene: SCNScene!
    
    var cameraVR: SCNNode!
    var cameraL: SCNNode!
    var cameraR: SCNNode!
    var cameraRollNode : SCNNode?
    var cameraPitchNode : SCNNode?
    var cameraYawNode : SCNNode?
    
    var motionManager : CMMotionManager?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        setupMotion()
        setupScene()
        setupNodes()

    }
    
    func setupMotion()
    {
        // Respond to user head movement. Refreshes the position of the camera 60 times per second.
        motionManager = CMMotionManager()
        motionManager?.deviceMotionUpdateInterval = 1.0 / 60.0
        motionManager?.startDeviceMotionUpdates(using: CMAttitudeReferenceFrame.xArbitraryZVertical)
    }
    
    func setupScene()
    {
        UIApplication.shared.isIdleTimerDisabled = true
        
        scnScene = SCNScene(named: "art.scnassets/ship.scn")!
    
        self.leftView.scene = scnScene
        self.leftView.showsStatistics = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        self.leftView.addGestureRecognizer(tapGesture)
        
        self.rightView.scene = scnScene
        
        self.leftView.delegate = self
        
    }
    
    func setupNodes()
    {
        cameraVR = scnScene.rootNode.childNode(withName: "VRCamera", recursively: true)
        
        cameraL = cameraVR.childNode(withName: "cameraL", recursively: false)
        cameraR = cameraVR.childNode(withName: "cameraR", recursively: false)
        
        cameraVR.position = SCNVector3Make(0, 15, -5)

        cameraVR.eulerAngles = SCNVector3Make(-90, 0, 0)
        
        cameraRollNode = SCNNode()
        cameraRollNode!.addChildNode(cameraVR)
        
        cameraPitchNode = SCNNode()
        cameraPitchNode!.addChildNode(cameraRollNode!)
        
        cameraYawNode = SCNNode()
        cameraYawNode!.addChildNode(cameraPitchNode!)
        
        scnScene.rootNode.addChildNode(cameraYawNode!)

        //interpupillary distance (IPD), and we refer to the distance between the two rendering cameras
        // that capture the virtual environment as the inter-camera distance (ICD). 
        // Although the IPD can vary from about 52mm to 78mm, average IPD 
        // (based on data from a survey of approximately 4,000 U.S. Army soldiers) is about 63.5 mm
        
        self.leftView.pointOfView = cameraL
        self.rightView.pointOfView = cameraR
    }
    
    func updateCamera()
    {
        DispatchQueue.main.async { () -> Void in
            if let mm = self.motionManager, let motion = mm.deviceMotion {
                let currentAttitude = motion.attitude
                
                var roll : Double = currentAttitude.roll
                
                if(UIApplication.shared.statusBarOrientation == UIInterfaceOrientation.landscapeRight){ roll = -1.0 * (-.pi - roll)}
                
                self.cameraRollNode!.eulerAngles.x = Float(roll)
                self.cameraPitchNode!.eulerAngles.z = Float(currentAttitude.pitch)
                self.cameraYawNode!.eulerAngles.y = Float(currentAttitude.yaw)
                
            }
        }
    }
    
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
        let scnView = self.leftView as SCNView
        
        // check what nodes are tapped
        let p = gestureRecognize.location(in: scnView)
        let hitResults = scnView.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result: AnyObject = hitResults[0]
            
            // get its material
            let material = result.node!.geometry!.firstMaterial!
            
            // highlight it
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            material.emission.contents = UIColor.red
            
            SCNTransaction.commit()
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}



extension GameViewController : SCNSceneRendererDelegate {
    
    func renderer(_ aRenderer: SCNSceneRenderer, updateAtTime time: TimeInterval){
        
        updateCamera()
        
    }
}

