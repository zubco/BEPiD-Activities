//
//  FoodItem.swift
//  Fitness
//
//  Created by Marcelo Reina on 15/08/17.
//  Copyright © 2017 Eldorado. All rights reserved.
//

import Foundation

struct FoodItem {
    let name: String
    let kilocalories: Double
}
