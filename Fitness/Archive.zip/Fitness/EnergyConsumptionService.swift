//
//  EnergyConsumptionService.swift
//  Fitness
//
//  Created by Marcelo Reina on 15/08/17.
//  Copyright © 2017 Eldorado. All rights reserved.
//

import Foundation

class EnergyConsumptionService {
    
    class func getTotalEnergyConsumedToday(completion: @escaping (Double?) -> ()) {
        let today = Date()
        HealthKitManager.shared.getTotalEnergyConsumedOn(specificDate: today) { (total) in
            DispatchQueue.main.async {
                completion(total)
            }
        }
    }
    
    class func getSteps(completion: @escaping(Double?) -> ()){
        let today = Date()
        HealthKitManager.shared.getTotalStepsWalked(specificDate: today){
            (total) in
            DispatchQueue.main.async{
                completion(total)
            }
        }
    }
    
    class func getCaloriesBurnt(completion: @escaping(Double?)->()){
        let today = Date()
        
        var weight:Double?
        var distance:Double?
        var time:Double?
        
        HealthKitManager.shared.getLastWeightData{  (value, unit) in
            if let wei = value{
                weight = wei
            }
        }
        
        HealthKitManager.shared.getExerciseTime(specificDate: today, completion: { (hours) in
            if let t = hours{
                time = t
            }
        })
        
        HealthKitManager.shared.getDistanceWalked(specificDate: today, completion: { (dist) in
            if let dist = dist{
                distance = dist
            }
        })
        
        DispatchQueue.main.async{
            if (distance == nil || time == nil || weight == nil){
                completion(nil)
                return
            }
            
            let speed = (distance!/1000)/time!
            
            let caloriesBurnt = (0.0215 * pow(speed, 3.0) - 0.1765 * pow(speed, 2.0) + 0.8710 * speed + 1.4577) * weight! * time!
            
            completion(caloriesBurnt)
        }
    }
    
}
