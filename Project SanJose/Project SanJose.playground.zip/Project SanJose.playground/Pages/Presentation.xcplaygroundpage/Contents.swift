/*:
  # Project San Jose
 ## The console hacking game!
 ---
*/
/*:
 ![X,Y axis](Header.png "San Jose iSystems template")
 
 “Project San Jose” is what we may call a console-hacking game. Its visual interface resembles the screen of a computer working-station.
 However, unlike a regular console, this one simply displays the results of your actions. 
 One might wonder: “But wait, how do you type commands if not using the console bash?” That’s where the magic comes in: the console responds to commands typed on the Playground page!

 [Next](@next)
 */
